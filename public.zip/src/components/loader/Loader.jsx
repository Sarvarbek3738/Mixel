import React from "react";
import "./Loader.css";
function Loader() {
  return (
    <div className="loaderComponent">
      <div class="lds-roller">
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
      </div>
    </div>
  );
}

export default Loader;
